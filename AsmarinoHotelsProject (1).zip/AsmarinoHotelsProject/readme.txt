Important Note* - Unfortunately my visual studio forms would not run. Last night, while trying to send my project, visual studio crashed. It would not let me run any forms or continue to work on them due to it not being able to connect to my server. I tried everything imaginable to get it to connect but had no success. I apologize for the state of my project, I hate to submit an assignment that does not meet the desired expectations. However, after countless hours trying to get my project back to the state it was in before visual studio crashed, I have admitted defeat. Again, I apologize, I have been working on Phase II for several days, I hope you do not think this was a result of waiting till the last minute. Please let me know if there is anyway I can make this up. 

1. Run Build Script
2. Open Solution
3. Pick a guest name to search(for example: Kirsten Jiggle)
4. Run Forms
5. Use Specific Parameters