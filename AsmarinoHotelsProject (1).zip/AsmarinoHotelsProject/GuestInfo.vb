﻿Public Class FrmGuestInfo
    Private m_GuestID As Int32
    Public Property GuestID
        Get
            Return m_GuestID
        End Get
        Set(value)
            m_GuestID = value
        End Set
    End Property



    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub


End Class
