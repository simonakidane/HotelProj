﻿Partial Class PaymentResults
End Class

Namespace PaymentResultsTableAdapters
    Partial Public Class PaymentInfoTableAdapter
    End Class
End Namespace
