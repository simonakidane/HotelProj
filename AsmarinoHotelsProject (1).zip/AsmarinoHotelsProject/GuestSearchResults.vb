﻿Partial Class GuestSearchResults
End Class

Namespace GuestSearchResultsTableAdapters

    Partial Public Class spGuestTableAdapter
    End Class
End Namespace
