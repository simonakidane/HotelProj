﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmGuestInfo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim GuestIDLabel As System.Windows.Forms.Label
        Dim FirstNameLabel As System.Windows.Forms.Label
        Dim LastNameLabel As System.Windows.Forms.Label
        Dim lblZipCode As System.Windows.Forms.Label
        Dim PhoneNumberLabel As System.Windows.Forms.Label
        Dim lblStreetAddress As System.Windows.Forms.Label
        Dim lblUSState As System.Windows.Forms.Label
        Dim lblCity As System.Windows.Forms.Label
        Me.GuestIDTextBox = New System.Windows.Forms.TextBox()
        Me.SpGetGuestBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.GuestSearchResults = New AsmarinoHotels.GuestSearchResults()
        Me.FirstNameTextBox = New System.Windows.Forms.TextBox()
        Me.LastNameTextBox = New System.Windows.Forms.TextBox()
        Me.txtZipCode = New System.Windows.Forms.TextBox()
        Me.PhoneNumberTextBox = New System.Windows.Forms.TextBox()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnReservations = New System.Windows.Forms.Button()
        Me.txtStreetAddress = New System.Windows.Forms.TextBox()
        Me.BookingBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PaymentInfoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SpGuestTableAdapter = New AsmarinoHotels.GuestSearchResultsTableAdapters.spGuestTableAdapter()
        Me.txtState = New System.Windows.Forms.TextBox()
        Me.txtCity = New System.Windows.Forms.TextBox()
        GuestIDLabel = New System.Windows.Forms.Label()
        FirstNameLabel = New System.Windows.Forms.Label()
        LastNameLabel = New System.Windows.Forms.Label()
        lblZipCode = New System.Windows.Forms.Label()
        PhoneNumberLabel = New System.Windows.Forms.Label()
        lblStreetAddress = New System.Windows.Forms.Label()
        lblUSState = New System.Windows.Forms.Label()
        lblCity = New System.Windows.Forms.Label()
        CType(Me.SpGetGuestBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GuestSearchResults, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BookingBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PaymentInfoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GuestIDLabel
        '
        GuestIDLabel.AutoSize = True
        GuestIDLabel.Location = New System.Drawing.Point(43, 229)
        GuestIDLabel.Name = "GuestIDLabel"
        GuestIDLabel.Size = New System.Drawing.Size(52, 13)
        GuestIDLabel.TabIndex = 1
        GuestIDLabel.Text = "Guest ID:"
        '
        'FirstNameLabel
        '
        FirstNameLabel.AutoSize = True
        FirstNameLabel.Location = New System.Drawing.Point(44, 18)
        FirstNameLabel.Name = "FirstNameLabel"
        FirstNameLabel.Size = New System.Drawing.Size(60, 13)
        FirstNameLabel.TabIndex = 3
        FirstNameLabel.Text = "First Name:"
        '
        'LastNameLabel
        '
        LastNameLabel.AutoSize = True
        LastNameLabel.Location = New System.Drawing.Point(44, 41)
        LastNameLabel.Name = "LastNameLabel"
        LastNameLabel.Size = New System.Drawing.Size(61, 13)
        LastNameLabel.TabIndex = 5
        LastNameLabel.Text = "Last Name:"
        '
        'lblZipCode
        '
        lblZipCode.AutoSize = True
        lblZipCode.Location = New System.Drawing.Point(44, 164)
        lblZipCode.Name = "lblZipCode"
        lblZipCode.Size = New System.Drawing.Size(53, 13)
        lblZipCode.TabIndex = 13
        lblZipCode.Text = "Zip Code:"
        '
        'PhoneNumberLabel
        '
        PhoneNumberLabel.AutoSize = True
        PhoneNumberLabel.Location = New System.Drawing.Point(44, 201)
        PhoneNumberLabel.Name = "PhoneNumberLabel"
        PhoneNumberLabel.Size = New System.Drawing.Size(81, 13)
        PhoneNumberLabel.TabIndex = 15
        PhoneNumberLabel.Text = "Phone Number:"
        '
        'lblStreetAddress
        '
        lblStreetAddress.AutoSize = True
        lblStreetAddress.Location = New System.Drawing.Point(44, 67)
        lblStreetAddress.Name = "lblStreetAddress"
        lblStreetAddress.Size = New System.Drawing.Size(48, 13)
        lblStreetAddress.TabIndex = 19
        lblStreetAddress.Text = "Address:"
        '
        'lblUSState
        '
        lblUSState.AutoSize = True
        lblUSState.Location = New System.Drawing.Point(44, 128)
        lblUSState.Name = "lblUSState"
        lblUSState.Size = New System.Drawing.Size(35, 13)
        lblUSState.TabIndex = 21
        lblUSState.Text = "State:"
        '
        'lblCity
        '
        lblCity.AutoSize = True
        lblCity.Location = New System.Drawing.Point(44, 92)
        lblCity.Name = "lblCity"
        lblCity.Size = New System.Drawing.Size(27, 13)
        lblCity.TabIndex = 23
        lblCity.Text = "City:"
        '
        'GuestIDTextBox
        '
        Me.GuestIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SpGetGuestBindingSource, "GuestID", True))
        Me.GuestIDTextBox.Enabled = False
        Me.GuestIDTextBox.Location = New System.Drawing.Point(130, 229)
        Me.GuestIDTextBox.Name = "GuestIDTextBox"
        Me.GuestIDTextBox.Size = New System.Drawing.Size(51, 20)
        Me.GuestIDTextBox.TabIndex = 2
        '
        'SpGetGuestBindingSource
        '
        Me.SpGetGuestBindingSource.DataMember = "spGetGuest"
        Me.SpGetGuestBindingSource.DataSource = Me.GuestSearchResults
        '
        'GuestSearchResults
        '
        Me.GuestSearchResults.DataSetName = "GuestSearchResults"
        Me.GuestSearchResults.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'FirstNameTextBox
        '
        Me.FirstNameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SpGetGuestBindingSource, "FirstName", True))
        Me.FirstNameTextBox.Enabled = False
        Me.FirstNameTextBox.Location = New System.Drawing.Point(129, 18)
        Me.FirstNameTextBox.Name = "FirstNameTextBox"
        Me.FirstNameTextBox.Size = New System.Drawing.Size(100, 20)
        Me.FirstNameTextBox.TabIndex = 4
        '
        'LastNameTextBox
        '
        Me.LastNameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SpGetGuestBindingSource, "LastName", True))
        Me.LastNameTextBox.Enabled = False
        Me.LastNameTextBox.Location = New System.Drawing.Point(129, 41)
        Me.LastNameTextBox.Name = "LastNameTextBox"
        Me.LastNameTextBox.Size = New System.Drawing.Size(100, 20)
        Me.LastNameTextBox.TabIndex = 6
        '
        'txtZipCode
        '
        Me.txtZipCode.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SpGetGuestBindingSource, "ZipCode", True))
        Me.txtZipCode.Enabled = False
        Me.txtZipCode.Location = New System.Drawing.Point(130, 164)
        Me.txtZipCode.Name = "txtZipCode"
        Me.txtZipCode.Size = New System.Drawing.Size(100, 20)
        Me.txtZipCode.TabIndex = 14
        '
        'PhoneNumberTextBox
        '
        Me.PhoneNumberTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SpGetGuestBindingSource, "PhoneNumber", True))
        Me.PhoneNumberTextBox.Enabled = False
        Me.PhoneNumberTextBox.Location = New System.Drawing.Point(130, 198)
        Me.PhoneNumberTextBox.Name = "PhoneNumberTextBox"
        Me.PhoneNumberTextBox.Size = New System.Drawing.Size(100, 20)
        Me.PhoneNumberTextBox.TabIndex = 16
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(39, 271)
        Me.btnClose.Margin = New System.Windows.Forms.Padding(2)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(56, 19)
        Me.btnClose.TabIndex = 17
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnReservations
        '
        Me.btnReservations.Location = New System.Drawing.Point(130, 271)
        Me.btnReservations.Margin = New System.Windows.Forms.Padding(2)
        Me.btnReservations.Name = "btnReservations"
        Me.btnReservations.Size = New System.Drawing.Size(99, 19)
        Me.btnReservations.TabIndex = 18
        Me.btnReservations.Text = "Reservations"
        Me.btnReservations.UseVisualStyleBackColor = True
        '
        'txtStreetAddress
        '
        Me.txtStreetAddress.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SpGetGuestBindingSource, "StreetAddress", True))
        Me.txtStreetAddress.Enabled = False
        Me.txtStreetAddress.Location = New System.Drawing.Point(129, 67)
        Me.txtStreetAddress.Name = "txtStreetAddress"
        Me.txtStreetAddress.Size = New System.Drawing.Size(210, 20)
        Me.txtStreetAddress.TabIndex = 20
        '
        'SpGuestTableAdapter
        '
        Me.SpGuestTableAdapter.ClearBeforeFill = True
        '
        'txtState
        '
        Me.txtState.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SpGetGuestBindingSource, "ZipCode", True))
        Me.txtState.Enabled = False
        Me.txtState.Location = New System.Drawing.Point(130, 128)
        Me.txtState.Name = "txtState"
        Me.txtState.Size = New System.Drawing.Size(51, 20)
        Me.txtState.TabIndex = 22
        '
        'txtCity
        '
        Me.txtCity.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SpGetGuestBindingSource, "ZipCode", True))
        Me.txtCity.Enabled = False
        Me.txtCity.Location = New System.Drawing.Point(130, 92)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(100, 20)
        Me.txtCity.TabIndex = 24
        '
        'FrmGuestInfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(386, 305)
        Me.Controls.Add(lblCity)
        Me.Controls.Add(Me.txtCity)
        Me.Controls.Add(lblUSState)
        Me.Controls.Add(Me.txtState)
        Me.Controls.Add(lblStreetAddress)
        Me.Controls.Add(Me.txtStreetAddress)
        Me.Controls.Add(Me.btnReservations)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(GuestIDLabel)
        Me.Controls.Add(Me.GuestIDTextBox)
        Me.Controls.Add(FirstNameLabel)
        Me.Controls.Add(Me.FirstNameTextBox)
        Me.Controls.Add(LastNameLabel)
        Me.Controls.Add(Me.LastNameTextBox)
        Me.Controls.Add(lblZipCode)
        Me.Controls.Add(Me.txtZipCode)
        Me.Controls.Add(PhoneNumberLabel)
        Me.Controls.Add(Me.PhoneNumberTextBox)
        Me.Name = "FrmGuestInfo"
        Me.Text = "Guest Information"
        CType(Me.SpGetGuestBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GuestSearchResults, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BookingBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PaymentInfoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GuestIDTextBox As TextBox
    Friend WithEvents FirstNameTextBox As TextBox
    Friend WithEvents LastNameTextBox As TextBox
    Friend WithEvents txtZipCode As TextBox
    Friend WithEvents PhoneNumberTextBox As TextBox
    Friend WithEvents BookingBindingSource As BindingSource
    Friend WithEvents PaymentInfoBindingSource As BindingSource
    Friend WithEvents btnClose As Button
    Friend WithEvents btnReservations As Button
    Friend WithEvents txtStreetAddress As TextBox
    Friend WithEvents SpGetGuestBindingSource As BindingSource
    Friend WithEvents GuestSearchResults As GuestSearchResults
    Friend WithEvents SpGuestTableAdapter As GuestSearchResultsTableAdapters.spGuestTableAdapter
    Friend WithEvents txtState As TextBox
    Friend WithEvents txtCity As TextBox
End Class
