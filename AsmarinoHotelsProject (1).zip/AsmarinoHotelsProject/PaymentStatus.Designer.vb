﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmPaymentStatus
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblPaymentStatus = New System.Windows.Forms.Label()
        Me.lblPaymentMethod = New System.Windows.Forms.Label()
        Me.lblCardInfo = New System.Windows.Forms.Label()
        Me.txtPaymentStatus = New System.Windows.Forms.TextBox()
        Me.txtPaymentMethod = New System.Windows.Forms.TextBox()
        Me.txtCardInfo = New System.Windows.Forms.TextBox()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.PaymentResults = New AsmarinoHotels.PaymentResults()
        Me.PaymentInfoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PaymentInfoTableAdapter = New AsmarinoHotels.PaymentResultsTableAdapters.PaymentInfoTableAdapter()
        CType(Me.PaymentResults, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PaymentInfoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblPaymentStatus
        '
        Me.lblPaymentStatus.AutoSize = True
        Me.lblPaymentStatus.Location = New System.Drawing.Point(36, 40)
        Me.lblPaymentStatus.Name = "lblPaymentStatus"
        Me.lblPaymentStatus.Size = New System.Drawing.Size(109, 17)
        Me.lblPaymentStatus.TabIndex = 0
        Me.lblPaymentStatus.Text = "Payment status:"
        '
        'lblPaymentMethod
        '
        Me.lblPaymentMethod.AutoSize = True
        Me.lblPaymentMethod.Location = New System.Drawing.Point(36, 76)
        Me.lblPaymentMethod.Name = "lblPaymentMethod"
        Me.lblPaymentMethod.Size = New System.Drawing.Size(118, 17)
        Me.lblPaymentMethod.TabIndex = 1
        Me.lblPaymentMethod.Text = "Payment method:"
        '
        'lblCardInfo
        '
        Me.lblCardInfo.AutoSize = True
        Me.lblCardInfo.Location = New System.Drawing.Point(36, 115)
        Me.lblCardInfo.Name = "lblCardInfo"
        Me.lblCardInfo.Size = New System.Drawing.Size(69, 17)
        Me.lblCardInfo.TabIndex = 2
        Me.lblCardInfo.Text = "Card info:"
        '
        'txtPaymentStatus
        '
        Me.txtPaymentStatus.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PaymentInfoBindingSource, "PaymentStatus", True))
        Me.txtPaymentStatus.Enabled = False
        Me.txtPaymentStatus.Location = New System.Drawing.Point(195, 34)
        Me.txtPaymentStatus.Name = "txtPaymentStatus"
        Me.txtPaymentStatus.Size = New System.Drawing.Size(172, 22)
        Me.txtPaymentStatus.TabIndex = 3
        '
        'txtPaymentMethod
        '
        Me.txtPaymentMethod.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PaymentInfoBindingSource, "PaymentMethod", True))
        Me.txtPaymentMethod.Enabled = False
        Me.txtPaymentMethod.Location = New System.Drawing.Point(195, 76)
        Me.txtPaymentMethod.Name = "txtPaymentMethod"
        Me.txtPaymentMethod.Size = New System.Drawing.Size(172, 22)
        Me.txtPaymentMethod.TabIndex = 4
        '
        'txtCardInfo
        '
        Me.txtCardInfo.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PaymentInfoBindingSource, "CardInformation", True))
        Me.txtCardInfo.Enabled = False
        Me.txtCardInfo.Location = New System.Drawing.Point(195, 115)
        Me.txtCardInfo.Name = "txtCardInfo"
        Me.txtCardInfo.Size = New System.Drawing.Size(232, 22)
        Me.txtCardInfo.TabIndex = 5
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(195, 172)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(75, 23)
        Me.btnClose.TabIndex = 6
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'PaymentResults
        '
        Me.PaymentResults.DataSetName = "PaymentResults"
        Me.PaymentResults.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'PaymentInfoBindingSource
        '
        Me.PaymentInfoBindingSource.DataMember = "PaymentInfo"
        Me.PaymentInfoBindingSource.DataSource = Me.PaymentResults
        '
        'PaymentInfoTableAdapter
        '
        Me.PaymentInfoTableAdapter.ClearBeforeFill = True
        '
        'frmPaymentStatus
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(477, 231)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.txtCardInfo)
        Me.Controls.Add(Me.txtPaymentMethod)
        Me.Controls.Add(Me.txtPaymentStatus)
        Me.Controls.Add(Me.lblCardInfo)
        Me.Controls.Add(Me.lblPaymentMethod)
        Me.Controls.Add(Me.lblPaymentStatus)
        Me.Name = "frmPaymentStatus"
        Me.Text = "Payment Status"
        CType(Me.PaymentResults, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PaymentInfoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblPaymentStatus As Label
    Friend WithEvents lblPaymentMethod As Label
    Friend WithEvents lblCardInfo As Label
    Friend WithEvents txtPaymentStatus As TextBox
    Friend WithEvents txtPaymentMethod As TextBox
    Friend WithEvents txtCardInfo As TextBox
    Friend WithEvents btnClose As Button
    Friend WithEvents PaymentResults As PaymentResults
    Friend WithEvents PaymentInfoBindingSource As BindingSource
    Friend WithEvents PaymentInfoTableAdapter As PaymentResultsTableAdapters.PaymentInfoTableAdapter
End Class
