﻿Public Class frmPaymentStatus
    Private Sub Payment_Status_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'PaymentResults.PaymentInfo' table. You can move, or remove it, as needed.
        Me.PaymentInfoTableAdapter.Fill(Me.PaymentResults.PaymentInfo)

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class