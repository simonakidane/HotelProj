USE [HotelProject]
GO

CREATE VIEW [dbo].[vwGuestSearch]
AS
SELECT        UPPER(TRIM(LastName) + TRIM(FirstName)) AS FullName
FROM            dbo.Guest
GO




