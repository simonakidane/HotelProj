--Author: Simona Kidane
--Pear Reviewer: Gabriel Lopez
--Asmarino Hotels Project - Droping, Creating, and Loading Tables

IF NOT EXISTS(SELECT * FROM sys.databases
	WHERE NAME = N'HotelProject')
	CREATE DATABASE HotelProject
GO
USE HotelProject

-- Alters the path so the script can find the CSV files 
DECLARE @data_path NVARCHAR(256);
SELECT @data_path = 'C:\Users\Simona.Kidane\Documents\SQL Server Management Studio\PHASE 1\PHASE 1\HotelDatabaseProject\';

-- Delete tables if they exist. Tables are deleted in the opposite order they are created.

IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Service'
       )
	DROP TABLE [Service];
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Booking'
       )
	DROP TABLE Booking;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'PaymentInfo'
       )
	DROP TABLE PaymentInfo;

--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Reservation'
       )
	DROP TABLE Reservation;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Guest'
       )
	DROP TABLE Guest;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Room'
       )
	DROP TABLE Room;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'RoomType'
       )
	DROP TABLE RoomType;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Staff'
       )
	DROP TABLE Staff;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Hotel'
       )
	DROP TABLE Hotel;
--

--Creating Tables in Database
--Creating Hotel Table
CREATE TABLE Hotel
		(HotelID			INT CONSTRAINT pk_hotel_id PRIMARY KEY,
		 HotelName			NVARCHAR(30) CONSTRAINT nn_hotel_name  NOT NULL,
		 City				NVARCHAR (15),
		 State				NVARCHAR (2),
		 ZipCode			NVARCHAR(5) CONSTRAINT ck_guest_zipcode NOT NULL,
							CONSTRAINT ck_Hotel_ID 
								CHECK (HotelID BETWEEN 0 AND 5));

--Creating Staff Table
CREATE TABLE Staff
		(StaffID			INT CONSTRAINT pk_staff_id PRIMARY KEY,
		 HotelID			INT CONSTRAINT fk_hotel_id FOREIGN KEY (HotelID)
							REFERENCES Hotel(HotelID),
		 FirstName			NVARCHAR(20) CONSTRAINT nn_staff_fname NOT NULL,
		 LastName			NVARCHAR(26) CONSTRAINT nn_staff_lname NOT NULL,
		 JoinDate			DATE CONSTRAINT nn_staff_jdate NOT NULL,
		 JobTitle			NVARCHAR(26) CONSTRAINT nn_staff_title NOT NULL,
		 PhoneNumber		NVARCHAR(15) CONSTRAINT un_staff_phone UNIQUE NOT NULL,);
		 

-- Creating RoomType Table
CREATE TABLE RoomType
		(RoomTypeID			INT CONSTRAINT pk_roomtype_id PRIMARY KEY,
		 StandardPrice		MONEY CONSTRAINT nn_standard_price NOT NULL,
		 NumberofBeds		INT CONSTRAINT nn_num_beds NOT NULL
							);

--Create Room Table
CREATE TABLE Room
		(RoomID				INT CONSTRAINT pk_room_id PRIMARY KEY,
		 HotelID			INT FOREIGN KEY(HotelID)
							REFERENCES Hotel(HotelID),
		 RoomTypeID			INT CONSTRAINT fk_roomtype_id FOREIGN KEY(RoomTypeID)
							REFERENCES RoomType(RoomTypeID),
		 RoomNumber			NVARCHAR(5) CONSTRAINT un_room_num UNIQUE NOT NULL,
		 FloorNumber		NVARCHAR(25) CONSTRAINT nn_floor_num NOT NULL,
		 RoomRate			MONEY CONSTRAINT nn_room_rate NOT NULL);

-- Creating Guest Table
CREATE TABLE Guest
		(GuestID			INT CONSTRAINT pk_guest_id PRIMARY KEY,
		 FirstName			NVARCHAR(26) CONSTRAINT nn_guest_fname NOT NULL,
		 LastName			NVARCHAR(26) CONSTRAINT nn_guest_lname NOT NULL,
		 StreetAddress		NVARCHAR(30),
		 City				NVARCHAR (15),
		 State				NVARCHAR(2),
		 ZipCode			NVARCHAR(5) CONSTRAINT ck_guest_zipcode NOT NULL,
		 PhoneNumber		NVARCHAR(16) CONSTRAINT un_guest_phone UNIQUE NOT NULL);

-- Creating Reservation Table
CREATE TABLE Reservation
		(ReservationID		INT CONSTRAINT pk_reservation_id PRIMARY KEY,
		 GuestID			INT FOREIGN KEY(GuestID)
							REFERENCES Guest(GuestID),
		 RoomID				INT CONSTRAINT fk_room_id FOREIGN KEY(RoomID)
							REFERENCES Room(RoomID),		
		DateGenerated		DATE,
		CheckInDate			DATE CONSTRAINT nn_checkin_date NOT NULL,
		CheckOutDate		DATE CONSTRAINT nn_checkout_date NOT NULL,
		NumberOfGuests		INT CONSTRAINT nn_num_guests NOT NULL,
							CONSTRAINT ck_date CHECK(CheckOutDate >= CheckInDate));

--Creating PaymentInfo Table
CREATE TABLE PaymentInfo
		(PaymentID			INT CONSTRAINT pk_payment_id PRIMARY KEY,
		 ReservationID		INT CONSTRAINT fk_reservation_id FOREIGN KEY (ReservationID)
							REFERENCES Reservation(ReservationID) NOT NULL,
		 PaymentStatus		NVARCHAR(10) CONSTRAINT nn_payment_status NOT NULL,
		 PaymentMethod		NVARCHAR(15) CONSTRAINT nn_payment_method NOT NULL,
		 CardInformation	NVARCHAR(20) CONSTRAINT un_card_info UNIQUE NOT NULL);


--Creating Booking Table
CREATE TABLE Booking
		(BookingID			INT CONSTRAINT pk_booking_id PRIMARY KEY,
		 RoomID				INT FOREIGN KEY (RoomID)
							REFERENCES Room(RoomID),
		 ReservationID		INT FOREIGN KEY (ReservationID)
							REFERENCES Reservation(ReservationID),
		 BookingDate		DATE CONSTRAINT nn_booking_date NOT NULL);
--
--Creating Service Table
CREATE TABLE [Service]
		(ServiceID			INT CONSTRAINT pk_service_id PRIMARY KEY,
		 ReservationID		INT FOREIGN KEY (ReservationID)
							REFERENCES Reservation(ReservationID),	
		 ServiceType		NVARCHAR(15) CONSTRAINT nn_service_type NOT NULL,
		 DateReceived		DATE CONSTRAINT nn_service_date	NOT NULL,
		 ServiceCost		MONEY CONSTRAINT nn_service_cost NOT NULL); 
--
--Load table data

EXECUTE (N'BULK INSERT Hotel FROM ''' + @data_path + N'Hotel.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT Staff FROM ''' + @data_path + N'Staff.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--

EXECUTE (N'BULK INSERT RoomType FROM ''' + @data_path + N'RoomType.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT Room FROM ''' + @data_path + N'Room.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT Guest FROM ''' + @data_path + N'Guest.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT Reservation FROM ''' + @data_path + N'Reservation.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT PaymentInfo FROM ''' + @data_path + N'PaymentInfo.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT Booking FROM ''' + @data_path + N'Booking.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT Service FROM ''' + @data_path + N'Service.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
GO
SET NOCOUNT ON
SELECT 'RoomType'	 AS "Table",	COUNT(*) AS "Rows"	FROM RoomType		UNION
SELECT 'Room',						COUNT(*)			FROM Room		    UNION
SELECT 'Hotel',						COUNT(*)			FROM Hotel		    UNION
SELECT 'Staff',						COUNT(*)			FROM Staff		    UNION
SELECT 'PaymentInfo',				COUNT(*)			FROM PaymentInfo    UNION
SELECT 'Guest',						COUNT(*)			FROM Guest          UNION
SELECT 'Reservation',				COUNT(*)			FROM Reservation    UNION
SELECT 'Booking',					COUNT(*)			FROM Booking		UNION
SELECT 'Service',					COUNT(*)			FROM [Service]      
ORDER BY 1;
SET NOCOUNT OFF
GO