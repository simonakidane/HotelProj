USE [HotelProject]
GO

CREATE PROCEDURE [dbo].[spGetGuest]
	@param1 VARCHAR(100) = ''
	
AS
	SELECT	GuestID, FirstName, LastName, StreetAddress, City, State, ZipCode, PhoneNumber
	FROM	Guest
	INNER JOIN vwGuestSearch ON 
		UPPER(vwGuestSearch.FullName) = UPPER(TRIM(Guest.LastName) + TRIM(Guest.FirstName))

RETURN 0
GO


