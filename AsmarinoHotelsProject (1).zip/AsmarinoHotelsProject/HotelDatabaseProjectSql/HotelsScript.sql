--Author: Simona Kidane
--Hotel Project: Creating a view, UDF, and Sproc
USE HotelProject
GO
-- Creating a view that displays which guest have completed there payment or not, aswell, as their payment method. User can select * from this view based on if the condition assigned has been met (e.g. PaymentMenthod, PaymentStatus...)
--Drops view if exists
IF EXISTS 
	(SELECT *
	FROM sys.views
	WHERE name = 'GuestPaymentStatus')
	DROP VIEW	GuestPaymentStatus
GO
-- Creates GuestPaymentStatus view
CREATE VIEW GuestPaymentStatus
AS
	SELECT		Guest.FirstName,Guest.LastName,Guest.PhoneNumber,Guest.[State], PaymentInfo.PaymentStatus,PaymentInfo.PaymentMethod
	FROM		Guest
	INNER JOIN  PaymentInfo
			ON Guest.PaymentID = PaymentInfo.PaymentID
WITH CHECK OPTION;
GO
--Testing the functionality of the view
SELECT *
FROM GuestPaymentStatus
WHERE [PaymentStatus] = 'Incomplete'
-- Test
SELECT *
FROM GuestPaymentStatus
WHERE [PaymentStatus] = 'Complete'
--Test
SELECT *
FROM GuestPaymentStatus
WHERE [PaymentMethod] = 'Visa'


--Creating a purposeful UDF
-- Creating a function that masks the credict card number except for the last 4 digits, this is an incredibly important function, developers must be able to protect clients users information.
--Drops function if exists
IF EXISTS 
	(SELECT *
	FROM sys.objects 
	WHERE name = 'F_CC_Mask')
	DROP FUNCTION [dbo].[F_CC_Mask]
GO
-- Creates function F_CC_Mask
CREATE FUNCTION [dbo].[F_CC_Mask]
		(@Input		NVARCHAR(20))
--
		RETURNS		NVARCHAR(20)
		AS	
		BEGIN	
		SET		@Input = 'xxxx-xxxx-xxxx-' + SUBSTRING(@Input,16,4); 
		RETURN	@Input;
--
		END;
GO
SELECT [PaymentID]
      ,[PaymentStatus]
      ,[PaymentMethod]
      ,[dbo].[F_CC_Mask](CardInformation) AS 'CardInformation'
  FROM [HotelProject].[dbo].[PaymentInfo]

--Creating a SPROC that standardizes all the fields within the Guest table to improve the readability for management when creating reports
--Drops procedure if exists
IF EXISTS 
	(SELECT *
	FROM sys.objects 
	WHERE name = 'StandardizedNameFields')
	DROP PROCEDURE [dbo].[StandardizedNameFields]
GO
--Creates Procedure
CREATE PROCEDURE [dbo].[StandardizedNameFields]
AS
SET NOCOUNT ON
UPDATE [HotelProject].[dbo].[Guest]
Set [FirstName] = UPPER([FirstName]),
    [LastName] = UPPER([LastName]),
    [StreetAddress] = UPPER([StreetAddress]),
    [City] = UPPER([City]),
    [State] = UPPER([State])
FROM [HotelProject].[dbo].[Guest]
GO

--Testing the functionality of SPROC
EXEC [dbo].[StandardizedNameFields]
SELECT *	
FROM [HotelProject].[dbo].[Guest];