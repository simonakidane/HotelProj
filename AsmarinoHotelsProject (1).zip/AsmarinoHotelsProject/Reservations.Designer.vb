﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmReservations
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.ReservationID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RoomNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FloorNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DateGenerated = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CheckInDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CheckOutDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NumberOfGuests = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReservationResultsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ReservationResults = New AsmarinoHotels.ReservationResults()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnPayments = New System.Windows.Forms.Button()
        Me.ReservationBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.ReservationDataSet = New AsmarinoHotels.ReservationDataSet()
        Me.ReservationDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ReservationBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ReservationTableAdapter = New AsmarinoHotels.ReservationDataSetTableAdapters.ReservationTableAdapter()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ReservationResultsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ReservationResults, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ReservationBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ReservationDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ReservationDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ReservationBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ReservationID, Me.RoomNumber, Me.FloorNumber, Me.DateGenerated, Me.CheckInDate, Me.CheckOutDate, Me.NumberOfGuests})
        Me.DataGridView1.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.ReservationBindingSource1, "ReservationID", True))
        Me.DataGridView1.DataSource = Me.ReservationDataSetBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(36, 26)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(2)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 51
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(535, 138)
        Me.DataGridView1.TabIndex = 0
        '
        'ReservationID
        '
        Me.ReservationID.HeaderText = "Reservation ID"
        Me.ReservationID.Name = "ReservationID"
        Me.ReservationID.ReadOnly = True
        '
        'RoomNumber
        '
        Me.RoomNumber.HeaderText = "Room Number"
        Me.RoomNumber.Name = "RoomNumber"
        Me.RoomNumber.ReadOnly = True
        '
        'FloorNumber
        '
        Me.FloorNumber.HeaderText = "Floor Number"
        Me.FloorNumber.Name = "FloorNumber"
        Me.FloorNumber.ReadOnly = True
        '
        'DateGenerated
        '
        Me.DateGenerated.HeaderText = "Date Generated"
        Me.DateGenerated.Name = "DateGenerated"
        Me.DateGenerated.ReadOnly = True
        '
        'CheckInDate
        '
        Me.CheckInDate.HeaderText = "Check In Date"
        Me.CheckInDate.Name = "CheckInDate"
        Me.CheckInDate.ReadOnly = True
        '
        'CheckOutDate
        '
        Me.CheckOutDate.HeaderText = "Check Out Date"
        Me.CheckOutDate.Name = "CheckOutDate"
        Me.CheckOutDate.ReadOnly = True
        '
        'NumberOfGuests
        '
        Me.NumberOfGuests.HeaderText = "Number Of Guests"
        Me.NumberOfGuests.Name = "NumberOfGuests"
        Me.NumberOfGuests.ReadOnly = True
        '
        'ReservationResultsBindingSource
        '
        Me.ReservationResultsBindingSource.DataSource = Me.ReservationResults
        Me.ReservationResultsBindingSource.Position = 0
        '
        'ReservationResults
        '
        Me.ReservationResults.DataSetName = "ReservationResults"
        Me.ReservationResults.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(36, 219)
        Me.btnClose.Margin = New System.Windows.Forms.Padding(2)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(56, 19)
        Me.btnClose.TabIndex = 1
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnPayments
        '
        Me.btnPayments.Location = New System.Drawing.Point(504, 219)
        Me.btnPayments.Margin = New System.Windows.Forms.Padding(2)
        Me.btnPayments.Name = "btnPayments"
        Me.btnPayments.Size = New System.Drawing.Size(66, 19)
        Me.btnPayments.TabIndex = 2
        Me.btnPayments.Text = "Payments"
        Me.btnPayments.UseVisualStyleBackColor = True
        '
        'ReservationBindingSource1
        '
        Me.ReservationBindingSource1.DataMember = "Reservation"
        Me.ReservationBindingSource1.DataSource = Me.ReservationDataSet
        '
        'ReservationDataSet
        '
        Me.ReservationDataSet.DataSetName = "ReservationDataSet"
        Me.ReservationDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ReservationDataSetBindingSource
        '
        Me.ReservationDataSetBindingSource.DataSource = Me.ReservationDataSet
        Me.ReservationDataSetBindingSource.Position = 0
        '
        'ReservationBindingSource
        '
        Me.ReservationBindingSource.DataMember = "Reservation"
        Me.ReservationBindingSource.DataSource = Me.ReservationDataSet
        '
        'ReservationTableAdapter
        '
        Me.ReservationTableAdapter.ClearBeforeFill = True
        '
        'frmReservations
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(600, 266)
        Me.Controls.Add(Me.btnPayments)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.DataGridView1)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "frmReservations"
        Me.Text = "Reservations"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ReservationResultsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ReservationResults, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ReservationBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ReservationDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ReservationDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ReservationBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnClose As Button
    Friend WithEvents btnPayments As Button
    Friend WithEvents ReservationResultsBindingSource As BindingSource
    Friend WithEvents ReservationResults As ReservationResults
    Friend WithEvents ReservationID As DataGridViewTextBoxColumn
    Friend WithEvents RoomNumber As DataGridViewTextBoxColumn
    Friend WithEvents FloorNumber As DataGridViewTextBoxColumn
    Friend WithEvents DateGenerated As DataGridViewTextBoxColumn
    Friend WithEvents CheckInDate As DataGridViewTextBoxColumn
    Friend WithEvents CheckOutDate As DataGridViewTextBoxColumn
    Friend WithEvents NumberOfGuests As DataGridViewTextBoxColumn
    Friend WithEvents ReservationBindingSource1 As BindingSource
    Friend WithEvents ReservationDataSet As ReservationDataSet
    Friend WithEvents ReservationDataSetBindingSource As BindingSource
    Friend WithEvents ReservationBindingSource As BindingSource
    Friend WithEvents ReservationTableAdapter As ReservationDataSetTableAdapters.ReservationTableAdapter
End Class
