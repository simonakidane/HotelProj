﻿Imports AsmarinoHotels.GuestSearchResultsTableAdapters

Public Class frmGuestSearch
    Private Sub btnClose_Click(sender As Object, e As EventArgs)
        Me.Close()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Dim param1 As String
        Dim dt As New GuestSearchResults.spGetGuestDataTable
        param1 = Me.txtLastName.Text.Trim & Me.txtFirstName.Text.Trim
        Dim mySearchResults As New AsmarinoHotels.GuestSearchResultsTableAdapters.spGuestTableAdapter
        mySearchResults.Fill(dt, param1)

        If dt.Rows.Count = 0 Then
            MsgBox("No records exist for this guest", MsgBoxStyle.OkOnly, "Guest Search Results")
            Exit Sub
        Else 'If the search returns a record
            FrmGuestInfo.GuestID = CType(dt.Rows(0).Item("GuestID"), Int32)
        End If
        FrmGuestInfo.Show()
    End Sub



    Private Sub frmGuestSearch_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class